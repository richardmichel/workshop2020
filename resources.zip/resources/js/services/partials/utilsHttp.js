
export const requestF = (config) => {
	return config;
};
export const requestError = (error) => {
	return error;
};
export const responseF = (response) => {
	return response;
};
export const responseError = (error) => {
	return error;
};
