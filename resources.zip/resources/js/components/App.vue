<template>
	<transition>
		<router-view></router-view>
	</transition>
</template>

<script>
	export default {
		name: "App"
	}
</script>