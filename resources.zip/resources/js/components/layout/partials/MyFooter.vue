<template>
	<footer>
		<p>&copy 20202 Buenas Pelisc.</p>
		<p>Michel &copy 2020</p>
	</footer>
</template>

<script>
	export default {
		name: "MyFooter"
	}
</script>

<style>

	footer {
		padding: 20px;
		text-align: center;
		color: #686868;
		margin: 10px;
	}


</style>