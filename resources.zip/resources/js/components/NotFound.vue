<template>
	<div>
		<b-row>
			<b-col md="4">
				<p  class="font-red">
				No se encontró la página
				</p>
			</b-col>
		</b-row>
	</div>
</template>
<script>
	export default {
		name: "NotFound"
	}
</script>

<style scoped>

</style>